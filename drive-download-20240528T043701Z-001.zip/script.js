document.addEventListener('DOMContentLoaded', function() {
    const orderButtons = document.querySelectorAll('.order-btn');
    const cancelButton = document.getElementById('cancel-btn');

    orderButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            // Find the closest parent menu item
            const menuItem = this.closest('.menu-item');
            
            // Find the product name within the menu item
            const productName = menuItem.querySelector('h2').textContent;
            const quantity = menuItem.querySelector('#quantity').value;
            const size = menuItem.querySelector('#size').value;

            // Add fixed-width spaces between the product name, quantity, and size
            const orderDetails = `${productName.padEnd(20)} | Quantity: ${quantity.toString().padEnd(10)} | Size: ${size}`;

            const receipt = document.getElementById('receipt');
            const paragraph = document.createElement('p');
            paragraph.textContent = orderDetails;
            receipt.appendChild(paragraph);
        });
    });

    cancelButton.addEventListener('click', function() {
        const receipt = document.getElementById('receipt');
        receipt.innerHTML = ''; // Clear the content of the receipt
    });
});
